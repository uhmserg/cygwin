/usr/bin/update-mime-database -n /usr/share/mime
