find /usr/share/mime -mindepth 1 ! -path '*/mime/packages*' -delete
