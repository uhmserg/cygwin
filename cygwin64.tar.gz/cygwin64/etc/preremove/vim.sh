if [ -f /etc/vimrc ] && cmp -s /etc/defaults/etc/vimrc /etc/vimrc
then
    rm /etc/vimrc
fi

