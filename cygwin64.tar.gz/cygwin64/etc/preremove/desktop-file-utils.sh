rm -f /usr/share/applications/mimeinfo.cache
